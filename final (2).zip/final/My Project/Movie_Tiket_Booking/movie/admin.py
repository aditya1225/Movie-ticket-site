from django.contrib import admin
from .models import *

# Register your models here.
admin.site.register(Customer)
admin.site.register(Certificate)
admin.site.register(Movie_Type)
admin.site.register(Language)
admin.site.register(Movie)
admin.site.register(Set_Timing)
admin.site.register(Movie_Time)
admin.site.register(Booking)
